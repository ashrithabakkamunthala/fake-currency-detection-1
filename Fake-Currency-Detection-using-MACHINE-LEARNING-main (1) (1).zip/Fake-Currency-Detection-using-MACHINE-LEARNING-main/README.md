# Fake-Currency-Detection-using-MACHINE-LEARNING
This project explains how to detect fake currency notes via machine learning using the Python Scikit-learn library. Depending upon different features of a currency note, the machine learning model developed in this article is able to predict whether or not a currency note is fake.
